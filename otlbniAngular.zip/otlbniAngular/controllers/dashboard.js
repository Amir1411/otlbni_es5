app.controller('dashboard', ['$scope','$rootScope', function($scope, $rootScope){
	// alert('sdfgdfg');
}]);